import express from 'express'
import path from 'path'
import { getChairStatus } from './controllers/chairsController.js'
import { getNoiseStatus } from './controllers/noiseController.js'


const __dirname = path.resolve()
const PORT = process.env.PORT ?? 3000
const app = express()
  

app.set('view engine', 'ejs')
app.set('views', path.resolve(__dirname, 'ejs'))
console.log(app.get('views'))

const staticPath = path.resolve(__dirname, 'static');
app.use(express.static(staticPath));

app.use((req, res, next) => {
  if (req.url.endsWith('.css')) {
    res.setHeader('Content-Type', 'text/css');
  }
  if (req.url.endsWith('.js')) {
    res.setHeader('Content-Type', 'text/javascript');
  }
  next();
});

//app.use(express.json())
app.use(express.urlencoded({ extended: false }))


app.get('/', (req, res) => { // рендерим тайтл страницы
    res.render('index', {title: 'Main Page', active: 'main'})
})

app.get('/cafe', async (req, res) => {
    const chairStatus = await getChairStatus()
    const noiseStatus = await getNoiseStatus()
    console.log(chairStatus)
    console.log(noiseStatus)

    res.render('cafe', {title: 'Cafe', active: 'cafe', chairStatus, noiseStatus})
})

app.get('/example', async (req, res) => {
    const chairStatus = await getChairStatus()
    const noiseStatus = await getNoiseStatus()
    console.log(chairStatus)
    console.log(noiseStatus)

    res.render('example', {title: 'Example', active: 'example', chairStatus, noiseStatus})   
})

app.get('/getStatuses', async (req, res) => {
    const chairStatus = await getChairStatus()
    const noiseStatus = await getNoiseStatus()

    res.send({chairStatus, noiseStatus})
})

app.listen(PORT, () => {
    console.log(`Server has been started on port ${PORT}...`)
})