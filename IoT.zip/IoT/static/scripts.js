document.addEventListener("DOMContentLoaded", () => {
    updateStatus()
    setInterval(updateStatus, 2000);
}) 
function updateStatus() {
    fetch('/getStatuses')
    .then(response => response.json())
    .then(data => {
      // Обработка полученных данных
      const { chairStatus } = data;
      const { noiseStatus } = data;

      console.log(data)

      const statusElementChair = document.querySelector('.chairStatus');
      if (chairStatus) {
        statusElementChair.classList.add('chairFree');
        statusElementChair.classList.remove('chairOccup');
      } else {
        statusElementChair.classList.add('chairOccup');
        statusElementChair.classList.remove('chairFree');
      }

      const statusElementNoise = document.querySelector('.noiseStatus');
      if (noiseStatus) {
        statusElementNoise.classList.add('noiseLoud');
        statusElementNoise.classList.remove('noiseQuiet');
        statusElementNoise.textContent = 'Шумно';
      } else {
        statusElementNoise.classList.add('noiseQuiet');
        statusElementNoise.classList.remove('noiseLoud');
        statusElementNoise.textContent = 'Тихо';
      }

    })
    .catch(error => {
      console.error('Ошибка при выполнении запроса:', error);
    });
}

