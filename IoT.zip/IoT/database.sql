create TABLE noise(
    id SERIAL PRIMARY KEY,
    noise BOOLEAN
);

create TABLE chair(
    id SERIAL PRIMARY KEY,
    available BOOLEAN,
    table_id INT,
    FOREIGN KEY (table_id) REFERENCES noise(id)
);