import pool from '../db.js'

const updateNoiseStatus = async (noise) => {
      try {
        if (noise === NaN) {
            return({ message: 'Noise is NaN'});
        }
        // Обновление статуса доступности стула в базе данных
        const client = await pool.connect();
        await client.query('UPDATE noise SET noise = $1 WHERE id = 1', [noise]);
        client.release();
        return({ message: 'Noise updated successfully: '+ noise });

      } catch (error) {
        console.error('Error updating noise:', error);
        return({ error: 'Internal server error' });
    }
}

const getNoiseStatus = async () => { // получаем данные об уровне шума из БД
    const noise = await pool.query(`SELECT noise FROM noise LIMIT 1`) 
    return noise.rows[0].noise
}

export { updateNoiseStatus, getNoiseStatus };