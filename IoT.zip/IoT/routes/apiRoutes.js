import {Router} from 'express'
const router = new Router()
import {DataController} from '../controllers/dataController.js'

router.get('/api/server', DataController.ArduinoChair) // получаем данные о наличии мест из устройства

router.get('/api/server', DataController.ArduinoNoise) // получаем данные об уровне шума из устройства

//мб тут поставить не сервер, а ардуино?
router.patch('/api/server/:id', DataController.ChangeChair) // изменяем данные о наличии мест в БД

router.patch('/api/server/:id', DataController.ChangeNoise) // изменяем данные об уровне шума в БД


router.get('/api/chair/:id', DataController.GetChair) // получаем данные о наличии мест из БД

router.get('/api/noise/:id', DataController.GetNoise) // получаем данные об уровне шума из БД

export default router