import pool from '../db.js'

const updateChairStatus = async (available) => {
    try {
    // Обновление статуса доступности стула в базе данных
    const client = await pool.connect();
    await client.query('UPDATE chair SET available = $1 WHERE id = 1', [available]);
    client.release();
    return({ message: 'Chair status updated successfully: '+ available });

    } catch (error) {
    console.error('Error updating chair status:', error);
    return({ error: 'Internal server error' });
    }
}

const getChairStatus = async () => { // получаем данные о наличии мест из БД
    const chair = await pool.query(`SELECT available FROM chair LIMIT 1`) 
    return chair.rows[0].available
}

export { updateChairStatus, getChairStatus};