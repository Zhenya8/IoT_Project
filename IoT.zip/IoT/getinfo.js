import serialport from 'serialport'
import { ReadlineParser } from '@serialport/parser-readline'
import { SerialPortStream } from '@serialport/stream'
import { autoDetect } from '@serialport/bindings-cpp'
import { updateChairStatus } from './controllers/chairsController.js'
import { updateNoiseStatus } from './controllers/noiseController.js'


const binding = autoDetect()
const PortName = '/dev/cu.usbmodem146301'

let array = []

const port = new SerialPortStream({binding, path: PortName, baudRate: 9600 })
const parser = port.pipe(new ReadlineParser({ delimiter: '\r\n' }))

// Read the port data
port.on("open", () => {
  console.log('serial port open')
})

parser.on('data', async (data) => {
  const [availableStr, noiseStr] = data.split(',').map(value => value.trim());

  const available = parseInt(availableStr, 10);
  const noise = parseInt(noiseStr, 10);
  //const noise = Math.floor(parseInt(noiseStr, 10)/10);

    // Обновление статуса доступности стула
  const responseChair = await updateChairStatus(available === 1);

  if (responseChair?.message) {
    console.log(responseChair.message)
  }
  else {
    console.log(responseChair.error)
  }

  // Обновление статуса шума
  const responseNoise = await updateNoiseStatus(noise === 1);
  
  if (responseNoise?.message) {
    console.log(responseNoise.message)
  }
  else {
    console.log(responseNoise.error)
  }
})



//module.exports = { available, noise }