import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({
    user: "postgres",
    password: '03102002',
    host: "localhost",
    port: 5432,
    database: "iot_demo",
})

export { pool };
export default pool;